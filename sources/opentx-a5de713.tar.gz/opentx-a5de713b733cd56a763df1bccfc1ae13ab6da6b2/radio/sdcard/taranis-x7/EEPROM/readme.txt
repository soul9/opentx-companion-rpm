EEprom backups go in this folder.
EEprom backups can be generated from VERSION screen in RADIO SETUP
