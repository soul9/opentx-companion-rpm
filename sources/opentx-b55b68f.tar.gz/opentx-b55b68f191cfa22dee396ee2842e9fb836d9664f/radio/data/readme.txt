This folder contains sample data files from various telemetry sensors


Files:
  MODELE24-2014-07-11.csv
  MODELE24-2014-07-11-sport.log

Data from two FrSky FLVSS Smart Port LiPo Voltage Sensors one with
default appid 0xA1 (physical ID 1), the other one has appid changed 
to 0x48 (physical ID 8). It shows a problem with some cell readings
of second sensor.
