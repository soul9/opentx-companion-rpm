#!/bin/bash  
mogrify -negate -level 0,0,0 *.png

